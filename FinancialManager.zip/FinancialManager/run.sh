#!/bin/bash
echo "Starting AccountingDrien Comprehensive Accounting System..."
echo "Initializing server on port 5000..."
NODE_ENV=development tsx server/index.ts
